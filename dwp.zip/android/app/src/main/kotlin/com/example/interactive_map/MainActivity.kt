package lb.com.aub.dwp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
